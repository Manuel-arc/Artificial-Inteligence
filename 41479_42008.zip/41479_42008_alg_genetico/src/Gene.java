public class Gene {
    private int gen;

    public Gene(int n){
        this.gen = n;
    }

    public int getGen(){
        return gen;
    }

    public void setGen(int m){
        this.gen = m;
    }
}
